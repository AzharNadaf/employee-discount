import { Component, OnInit } from '@angular/core';

userName : String;
@Component({
  selector: 'app-homepage',
  templateUrl: './homepage.component.html',
  styleUrls: ['./homepage.component.css']
})
export class HomepageComponent implements OnInit {

  constructor() { 
    //this.userName = sessionStorage.getItem("UserName")
  
  }  

  ngOnInit() {
  }

}
