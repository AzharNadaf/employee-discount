import { BrowserModule } from '@angular/platform-browser';
import {BrowserAnimationsModule} from '@angular/platform-browser/animations';
import { CustomMaterialModule } from './core/material.module';
import {  NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { AppComponent } from './app.component'; 
import { FormsModule,ReactiveFormsModule } from '@angular/forms';
import{LoginService} from '../app/login/login.service'
import { HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http'; 
import { LoginComponent } from './login/login.component';
 
import { NgMultiSelectDropDownModule } from 'ng-multiselect-dropdown';
import { DlDateTimeDateModule, DlDateTimePickerModule } from 'angular-bootstrap-datetimepicker';
import { AgGridModule } from 'ag-grid-angular';
import{routing} from  './routes'
import { CookieService } from 'ngx-cookie-service';
import { NgDatepickerModule } from 'ng2-datepicker';
import { AmazingTimePickerModule } from 'amazing-time-picker'; 
import { from } from 'rxjs';
import { OwlDateTimeModule, OwlNativeDateTimeModule } from 'ng-pick-datetime';
import { HeaderComponent } from './header/header.component';
import { FooterComponent } from './footer/footer.component';
import { CellComponentComponent } from './cell-component/cell-component.component';
import { DatePipe } from '@angular/common';
 
import { HomepageComponent } from './homepage/homepage.component';
 

@NgModule({
  declarations: [
    AppComponent,
    LoginComponent, 
    HeaderComponent,
    CellComponentComponent,
    HomepageComponent,
    FooterComponent
    
  ],
  imports: [
    BrowserModule,NgDatepickerModule,AmazingTimePickerModule,FormsModule,AgGridModule.withComponents([]),
    ReactiveFormsModule,HttpClientModule,DlDateTimeDateModule,DlDateTimePickerModule,RouterModule,
    routing,BrowserAnimationsModule,CustomMaterialModule,NgMultiSelectDropDownModule,OwlDateTimeModule, 
    OwlNativeDateTimeModule
     
  ],
  providers: [  
     LoginService,CookieService, DatePipe,
  
   
    
  ],
  bootstrap: [AppComponent]
})
export class AppModule { }



